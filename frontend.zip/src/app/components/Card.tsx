import { Card as MyCard, CardHeader, CardBody, CardFooter, Button, Flex, Avatar, Heading, IconButton, Text, Image, ColorModeScript, useColorModeValue } from '@chakra-ui/react'
import { Box } from '@chakra-ui/react'
import { BsThreeDotsVertical } from "react-icons/bs";
import { BiLike, BiChat, BiShare } from "react-icons/bi";
import {
    AlertDialog,
    AlertDialogBody,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogContent,
    AlertDialogOverlay,
    AlertDialogCloseButton,
    useDisclosure,
} from '@chakra-ui/react';
import React, { useRef } from 'react';
import { useState } from 'react';

// params: { imageURL: string, title: string, description: string, cost: number }
export default function Card(params: any) {

    const bg = useColorModeValue('red.500', 'red.200')
    const color = useColorModeValue('white', 'gray.800')  

    const { isOpen, onOpen, onClose } = useDisclosure();
    const leastDestructiveRef = useRef(null);

    const [cost, setCost] = useState(100)    

    return (
        <Box m="10">
        <Flex align="center" justify="center" gap='2'>
            <MyCard maxW='md'>
            <CardHeader>
                <Flex gap='4'>
                <Flex flex='1' gap='4' alignItems='center' flexWrap='wrap'>
                    <Avatar name='Segun Adebayo' src='https://bit.ly/sage-adebayo' />

                    <Box>
                    <Heading size='sm'>Segun Adebayo</Heading>
                    {/* <Text>Creator, Chakra UI</Text> */}
                    </Box>
                </Flex>
                <IconButton
                    variant='ghost'
                    colorScheme='gray'
                    aria-label='See menu'
                    icon={<BsThreeDotsVertical />}
                />
                </Flex>
            </CardHeader>
            <Image
                objectFit='cover'
                // src='https://images.unsplash.com/photo-1531403009284-440f080d1e12?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1770&q=80'
                src={params.imageURL}
                alt='Chakra UI'
            />

            <CardBody>
                <Text>
                With Chakra UI, I wanted to sync the speed of development with the speed
                of design. I wanted the developer to be just as excited as the designer to
                create a screen.
                </Text>
            </CardBody>
            <CardFooter
                justify='space-between'
                flexWrap='wrap'
                sx={{
                '& > button': {
                    minW: '136px',
                },
                }}
                gap={10}
            >
                <Button colorScheme='green' flex='1' onClick={onOpen} width='50%'
                // leftIcon={<BiLike />}
                >
                Borrow
                </Button>
                {/* <Button flex='1' colorScheme='red' 
                // leftIcon={<BiChat />}
                >
                Bid
                </Button> */}
                {/* <Button flex='1' variant='ghost' 
                // leftIcon={<BiShare />}
                >
                Share
                </Button> */}
            </CardFooter>
        </MyCard>
        </Flex>
        <AlertDialog
            isOpen={isOpen}
            leastDestructiveRef={leastDestructiveRef}
            onClose={onClose}
            isCentered
    >
            <AlertDialogOverlay />

            <AlertDialogContent>
            <AlertDialogHeader>Current Highest Bid ${cost}</AlertDialogHeader>
            <AlertDialogCloseButton />
            <AlertDialogBody>
                Are you sure you want to borrow this item for the highest bid?
            </AlertDialogBody>
            <AlertDialogFooter>
            <Button ref={leastDestructiveRef} onClick={onClose}>
                No
                </Button>
                <Button colorScheme='red' ml={3}>
                Yes
                </Button>
            </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
    </Box>
    )
}