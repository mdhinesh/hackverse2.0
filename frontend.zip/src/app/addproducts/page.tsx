import Card from "../components/Card"
import {
    FormControl,
    FormLabel,
    FormErrorMessage,
    FormHelperText,
    Input,
    Box
  } from '@chakra-ui/react'

export default function AddProducts() {
    return (
        <Box m={10}>
            <FormControl>
                <FormLabel>Product name</FormLabel>
                <Input type='text' />
                <FormLabel>Lending prize</FormLabel>
                <Input type='text' />
                <FormLabel>Descripttion</FormLabel>
                <Input type='text' />
                <FormLabel>Image URL</FormLabel>
                <Input type='text' />
                {/* <FormHelperText>We'll never share your email.</FormHelperText> */}
            </FormControl>
        </Box>
    )
}